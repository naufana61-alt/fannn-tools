# Fann Tools (deploy ke Vercel)

1. Buat repo GitHub, upload isi folder ini (index.html, banner.mp4, api/, vercel.json). Ganti banner.mp4 dengan videomu sendiri (nama file sama).
2. Vercel > Add New Project > pilih repo tadi > Deploy.
3. Untuk YouTube dan Instagram: Settings > Environment Variables
   - COBALT_URL = alamat instance Cobalt (contoh https://cobalt.domainmu.com/)
   - COBALT_KEY = API key instance (kalau instance-nya minta)
   Lalu Redeploy.
4. HD AI (Image Enhancer): daftar di replicate.com, buat API token, lalu isi Environment Variable REPLICATE_API_TOKEN dan Redeploy. Pemakaian dikenai biaya per gambar oleh Replicate. Foto dikecilkan dulu ke 1280px lalu diperbesar AI sampai target (8K = skala sekitar 6x). Kalau 8K gagal, pakai 4K.
5. TikTok langsung jalan tanpa pengaturan tambahan.

Catatan: kode server ini belum diuji langsung (tidak ada akses internet saat dibuat).
Layanan pihak ketiga (tikwm, Cobalt) bisa berubah atau membatasi akses sewaktu-waktu.
Hanya unduh konten milik sendiri atau yang memang boleh diunduh.

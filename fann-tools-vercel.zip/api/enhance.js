// Fann Tools - AI upscaler (Real-ESRGAN via Replicate). Butuh env REPLICATE_API_TOKEN.
export const config = { api: { bodyParser: { sizeLimit: "4mb" } }, maxDuration: 60 };
export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (req.method !== "POST") return res.status(405).json({ error: "Gunakan POST" });
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return res.status(500).json({ error: "REPLICATE_API_TOKEN belum diisi di Vercel" });
  const { image, scale } = req.body || {};
  if (!image || !/^data:image\//.test(image)) return res.status(400).json({ error: "Gambar tidak valid" });
  const sc = Math.min(10, Math.max(2, parseInt(scale) || 4));
  try {
    const H = { Authorization: "Bearer " + token, "Content-Type": "application/json" };
    let p = await (await fetch("https://api.replicate.com/v1/models/nightmareai/real-esrgan/predictions", {
      method: "POST", headers: { ...H, Prefer: "wait=50" },
      body: JSON.stringify({ input: { image, scale: sc, face_enhance: false } }),
    })).json();
    for (let n = 0; n < 8 && p.status && !["succeeded", "failed", "canceled"].includes(p.status) && p.urls; n++) {
      await new Promise((r) => setTimeout(r, 3000));
      p = await (await fetch(p.urls.get, { headers: H })).json();
    }
    if (p.status !== "succeeded") return res.status(502).json({ error: "AI gagal: " + (p.error || p.detail || p.status || "tidak diketahui") + ". Coba target lebih kecil (4K)." });
    const url = Array.isArray(p.output) ? p.output[0] : p.output;
    return res.json({ url });
  } catch (e) {
    return res.status(500).json({ error: "Server error: " + e.message });
  }
}

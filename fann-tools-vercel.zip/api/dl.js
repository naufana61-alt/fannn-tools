// Fann Tools - API downloader (Vercel Serverless, Node 18+)
// TikTok: lewat tikwm (tanpa key). YouTube & Instagram: lewat instance Cobalt.
// Set Environment Variables di Vercel: COBALT_URL (contoh https://cobalt.domainmu.com/) dan COBALT_KEY (jika instance butuh).
export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  const url = (req.query.url || "").trim();
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: "Link tidak valid" });
  let host = "";
  try { host = new URL(url).hostname; } catch { return res.status(400).json({ error: "Link tidak valid" }); }
  try {
    if (/tiktok\.com$/i.test(host)) {
      const r = await fetch("https://www.tikwm.com/api/?hd=1&url=" + encodeURIComponent(url));
      const j = await r.json();
      if (j.code !== 0 || !j.data) return res.status(502).json({ error: j.msg || "TikTok gagal diproses" });
      const d = j.data, items = [];
      if (d.hdplay) items.push({ type: "video", label: "Video HD (tanpa watermark)", url: d.hdplay });
      if (d.play) items.push({ type: "video", label: "Video (tanpa watermark)", url: d.play });
      if (d.music) items.push({ type: "audio", label: "Audio MP3", url: d.music });
      return res.json({ title: d.title || "TikTok", thumb: d.cover, items });
    }
    if (/(youtube\.com|youtu\.be|instagram\.com)$/i.test(host) || /\.(youtube|instagram)\.com$/i.test(host)) {
      const base = process.env.COBALT_URL;
      if (!base) return res.status(500).json({ error: "COBALT_URL belum diisi di Environment Variables Vercel" });
      const headers = { Accept: "application/json", "Content-Type": "application/json" };
      if (process.env.COBALT_KEY) headers.Authorization = "Api-Key " + process.env.COBALT_KEY;
      const mk = (extra) => fetch(base, { method: "POST", headers, body: JSON.stringify({ url, ...extra }) }).then((r) => r.json());
      const v = await mk({ videoQuality: "1080" });
      if (v.status === "error") return res.status(502).json({ error: "Gagal: " + (v.error && v.error.code || "unknown") });
      const items = [];
      if (v.status === "tunnel" || v.status === "redirect") items.push({ type: "video", label: "Download " + (v.filename || "video"), url: v.url });
      if (v.status === "picker") (v.picker || []).forEach((p, i) => items.push({ type: p.type === "photo" ? "image" : "video", label: "Item " + (i + 1) + " (" + p.type + ")", url: p.url }));
      if (/youtu/i.test(host)) { try { const a = await mk({ downloadMode: "audio", audioFormat: "mp3" }); if (a.url) items.push({ type: "audio", label: "Audio MP3", url: a.url }); } catch {} }
      return res.json({ title: v.filename || "Media", thumb: null, items });
    }
    return res.status(400).json({ error: "Situs ini belum didukung" });
  } catch (e) {
    return res.status(500).json({ error: "Server error: " + e.message });
  }
}
